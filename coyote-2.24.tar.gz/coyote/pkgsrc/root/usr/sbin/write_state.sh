#!/bin/sh
# Write the status of the network subsystems to a temp file for later use
echo "IF_LOCAL=${IF_LOCAL}" > /tmp/netsubsys.state
echo "LOCAL_UP=${LOCAL_UP}" >> /tmp/netsubsys.state
echo "IF_INET=${IF_INET}" >> /tmp/netsubsys.state
echo "INET_UP=${INET_UP}" >> /tmp/netsubsys.state
[ -n "$IF_DMZ" ] && echo "IF_DMZ=${IF_DMZ}" >> /tmp/netsubsys.state
[ -n "$DMZ_UP" ] && echo "DMZ_UP=${DMZ_UP}" >> /tmp/netsubsys.state
[ -n "$CONNECTTIME" ] && echo CONNECTTIME=\"$CONNECTTIME\" >> /tmp/netsubsys.state
[ -n "$CONNECTSTRING" ] && echo CONNECTSTRING=\"$CONNECTSTRING\" >> /tmp/netsubsys.state

cat /tmp/netsubsys.state 1> /dev/null 2> /dev/null
