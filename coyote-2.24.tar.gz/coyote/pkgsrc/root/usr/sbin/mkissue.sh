#!/bin/sh
#Build Coyote Wellcome Screen
#by: Claudio Roberto Cussuol - 09-07-2004

. /etc/coyote/coyote.conf

[ -z "$SSH_PORT" ] && SSH_PORT=22
[ -z "$WEBADMIN_PORT" ] && WEBADMIN_PORT=8180

cat > /etc/issue << CLEOF

                                   iM
                                XM: MM    WELLCOME TO COYOTE LINUX
                           XMMMM   MSS
                       ,SMMM   7  M MX;
                    SMB7.          MM.    VERSION: `cat /var/lib/lrpkg/root.version`
                     MMSMM8       MM      LOCAL IP ADDRESS: $LOCAL_IPADDR
                    MM       MMMMM7
                 MMM    a.     MM2        To remotely access this router use
             MMMM,      .SM   MM          an SSH client to connect to port $SSH_PORT.
          MMMa            MMMMS,
        MM         :M    X0 M7.           Access the Coyote Web Admin by
      :M. rMMM2     Ma   M  M7            using the following URL:
     aM  M2   WMW    M  WMMM7             http://$LOCAL_IPADDR:$WEBADMIN_PORT
     M          M  :MM  MiM
    MM          MMMMWMi M M
    M          8MM    M M8 M              Coyote Linux offical website:
  MM          MMM     M .MM BXM           http://www.coyotelinux.com
 MM  MX      M07,0MMX M  ,MMMMMZ
 M   iMMMMMMM   i  Ma  MM@M.
 MMX        i7B,M
   MMMMBZMr Ba.SM2SM

  
CLEOF
