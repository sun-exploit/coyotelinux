#!/usr/bin/perl
#
#

sub copymodule {

my ($MOD) = @_;

$MOD="drivers/$MOD.o";

$CMD="cp $MOD pkgsrc/modules/lib/modules";

stat("$MOD");

print "Copying module: $MOD\n";

if ( ! -r $MOD ) {
	print "\nUnable to copy module ($MOD): $!\n";
	exit 1;
}

system($CMD);

}

sub setdeps {

my ($C1, $C2) = @_;

print "Checking module deps for ($C1,$C2)...\n";

open(DEPFILE, "data/netmods.txt") || die "Can't open netmods file: $!\n";

while (chomp($DEPLINE=<DEPFILE>)) {
	@DEPS=split(",",$DEPLINE);
	if ( $C1 eq $DEPS[0] ) {
		print "Module $C1 dep = $DEPS[1]\n"; 
		$DEP1=$DEPS[1];
	};
	if ( $C2 eq $DEPS[0] ) { 
		print "Module $C2 dep = $DEPS[1]\n";
		$DEP2=$DEPS[1];
	};
}

close (DEPFILE);

if ( $DEP1 ) { 
	copymodule($DEP1);
	print MODFILE "$DEP1\n";
};

if ( $DEP2 && ( $DEP2 ne $DEP1 ) ) { 
	copymodule($DEP2);	
	print MODFILE "$DEP2\n";
};

}

open(MODFILE, ">> pkgsrc/modules/etc/modules") || die "Can't open modules files: $!\n";

print "\nYou now need to specify the module name and parameters for your network cards.\n\n";
print "If you are using PCI or EISA cards, leave the IO and IRQ lines blank.\n\n";

print "Enter the module name for you local network card: ";
chomp($CARD1 = <STDIN>);
print "Enter IO address (Leave blank for PCI cards): ";
chomp($IO1 = <STDIN>);
print "Enter IRQ (Leave blank for PCI cards): ";
chomp($IRQ1 = <STDIN>);

print "\n";

print "Enter the module name for your Internet network card: ";
chomp($CARD2 = <STDIN>);
print "Enter IO address (Leave blank for PCI cards): ";
chomp($IO2 = <STDIN>);
print "Enter IRQ (Leave blank for PCI cards): ";
chomp($IRQ2 = <STDIN>);

setdeps($CARD1,$CARD2);

if ( $IO1 ) {$IO1="0x$IO1" unless $IO1 =~ m/^0x/};
if ( $IO2 ) {$IO2="0x$IO2" unless $IO2 =~ m/^0x/};

if ( $CARD1 eq $CARD2 ) {
	copymodule($CARD1);
	$IO3="";
	if ( $IO1 || $IO2 ) {
		if ( not $IO1 ) { $IO1 = "0x000" };
		if ( not $IO2 ) { $IO2 = "0x000" };
		$IO3="io=$IO1,$IO2";
	};
	$IRQ3="";
	if ( $IRQ1 || $IRQ2 ) {
		if ( not $IRQ1 ) { $IRQ1 = "-1" };
		if ( not $IRQ2 ) { $IRQ2 = "-1" };
		$IRQ3="irq=$IRQ1,$IRQ2";
	};
	print MODFILE "$CARD1 $IO3 $IRQ3\n";
} else {
	copymodule($CARD1);
	copymodule($CARD2);
	print MODFILE "$CARD1 ";
	if ( $IO1 ) {print MODFILE "io=$IO1 "};
	if ( $IRQ1 ) {print MODFILE "irq=$IRQ1"};
	print MODFILE "\n";
	print MODFILE "$CARD2 ";
	if ( $IO2 ) {print MODFILE "io=$IO2 "};
	if ( $IRQ2 ) {print MODFILE "irq=$IRQ2"};
	print MODFILE "\n";
};

close(MODFILE);
