#!/bin/sh
#
#

# load standard functions
. scripts/functions
. scripts/cfg-local
. scripts/cfg-dmz
. scripts/cfg-dhcpd
. scripts/cfg-language

CONFIG_FILE=floppy/config/coyote.cfg

clear
echo
echo "Coyote floppy builder script v2.9"
echo

if ! [ "$UID" = "0" ]; then
	echo "You should be logged in as root to create the Coyote floppy disk. Non-root users"
	echo "can experience permission problems under some distributions when attempting to"
	echo "access the floppy drive.  To cancel, press CTRL-C... to proceed, press enter"
	read JUNK
fi

reset_all

if [ "$1" = "-i" ]; then
	if [ ! -r flp.img ]; then
		echo "Floppy image update specified but no floppy image is present."
		exit 1
	fi
	DOFMT=NO
	DOIMG=YES
	FDCAPACITY=1440
    	FLOPPY=/dev/fd0u1440
else
    DOIMG=NO
    echo "Please choose the desired capacity for the created floppy:"
    echo
    echo "1) 1.44Mb (Safest and most reliable but may lack space needed for"
    echo "           some options)"
    echo "2) 1.68Mb (Good reliability with extra space) - recommended"
    echo "3) 1.72Mb (Most space but may not work on all systems or with all" 
    echo "           diskettes)"
    echo
    echo -n "Enter selection: "
    read FDCAP

    case $FDCAP in
    	1) FDCAPACITY=1440
    		if [ -a /dev/fd0u1440 ]; then
    			FLOPPY=/dev/fd0u1440
    		elif [ -a /dev/fd0H1440 ]; then
    			FLOPPY=/dev/fd0H1440
    		elif [ -a /dev/fd0h1440 ]; then
    			FLOPPY=/dev/fd0h1440
    		else
    			# No device available... try using a built-in
    			FLOPPY=data/dev/fd0u1440
    		fi			
    	   	;;
    	2) FDCAPACITY=1680
    		if [ -a /dev/fd0u1680 ]; then
    			FLOPPY=/dev/fd0u1680
    		else
    			FLOPPY=data/dev/fd0u1680
    		fi
    	   ;;
    	3) FDCAPACITY=1722
    		if [ -a /dev/fd0u1722 ]; then
    			FLOPPY=/dev/fd0u1722
    		else
    			FLOPPY=data/dev/fd0u1722
    		fi
    	   ;;
    	*) echo "Invalid capacity selection."
    	   exit
    	   ;;
    esac	
    if [ "$1" = "-n" ]; then
    	DOFMT=NO
    else
	DOFMT=YES
    fi
fi

ln -s data/kernel/drivers drivers
ln -s ../data/kernel/floppy/linux floppy/linux

echo
echo "Please select the type of Internet connection that your system uses."
echo
echo "1) Standard Ethernet Connection"
echo "2) PPP over Ethernet Connection"
echo "3) PPP Dialup Connection"
echo
echo -n "Enter Selection: "
read CONNTYPE

case $CONNTYPE in
	1)	. scripts/mkflp-ethernet
		;;
	2)	. scripts/mkflp-pppoe
		;;
	3)	. scripts/mkflp-ppp
		;;
	*)	echo "'$CONNTYPE' is not a valid option."
		;;
esac

