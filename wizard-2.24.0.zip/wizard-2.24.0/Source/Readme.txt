This directory contains the source code for the gzip windows DLL that I whipped up for
use with the Coyote Disk Creator.  I have released this source because it is basically
a hack of the GNU Gzip program (which is released under the GPL).

The gzip dll project is for Microsoft Visual C++ 6.0.

Joshua Jackson
jjackson@vortech.net