#!/bin/sh
#
# Builds the Coyote Development snapshot for upload to the FTP
# archive

# Update the snapshot version
SNAPVER=`date +%m%d%y`

echo "Building Coyote $SNAPVER snapshot..."
echo "${SNAPVER}-SNAP" > pkgsrc/root/var/lib/lrpkg/root.version

cd ..
tar -cvzf coyote-ap${SNAPVER}.tar.gz coyote-ap/

echo "Complete."

