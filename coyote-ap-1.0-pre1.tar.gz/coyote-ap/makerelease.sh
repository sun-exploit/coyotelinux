#!/bin/sh
#
# Builds a Coyote release version
# archive

if [ -z "$1" ]; then
	echo "Please specify the release version!"
	exit 1
fi

echo "Building Coyote AP $1 release..."

./resetall.sh

mkdir /tmp/coyote
cp . /tmp/coyote -Rpa
rm -f /tmp/coyote/makesnap.sh
rm -f /tmp/coyote/makerelease.sh
rm -f /tmp/coyote/resetall.sh
rm -f /tmp/coyote/buildall.sh
rm -f /tmp/coyote/newkernel.sh
rm -f /tmp/coyote/source

CWD=`pwd`

cd /tmp

echo "${1}" > coyote/pkgsrc/root/var/lib/lrpkg/root.version
echo > coyote/floppy/SYSLINUX.DPY
echo "Coyote Linux v${1}" >> coyote/floppy/SYSLINUX.DPY
echo >> coyote/floppy/SYSLINUX.DPY
echo "http://www.coyotelinux.com" >> coyote/floppy/SYSLINUX.DPY
echo >> coyote/floppy/SYSLINUX.DPY
echo >> coyote/floppy/SYSLINUX.DPY

tar -czf $CWD/coyote-ap-${1}.tar.gz coyote/
cd $CWD

rm -Rf /tmp/coyote

echo "Complete."

