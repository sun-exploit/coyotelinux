#!/bin/sh
#
# This utility removes the root password from an existing Coyote
# Linux floppy.

clear
echo "Coyote Linux root password removal utility 1.0.0"
echo
echo "To remove the root password from your Coyote Linux boot floppy, place"
echo "it in the floppy drive and press enter to continue (or press CTRL-C to"
echo "abort this script)."
read JUNK

mount /dev/fd0 mnt -t msdos
if ! [ $? = 0 ]; then
	echo "Failed to mount floppy."
	exit 1
fi

if [ -r mnt/etc.lrp ]; then
	ETCFILE=etc.lrp
elif [ -r mnt/etc.tgz ]; then
	ETCFILE=etc.tgz
else
	echo 'Unable to find "etc" package on floppy disk.'
	umount mnt
	exit 1
fi

mkdir pkgtmp
cp mnt/${ETCFILE} pkgtmp
cd pkgtmp
tar -xzf $ETCFILE

if ! [ -r etc/shadow ]; then
	echo "Unable to locate password database file."
	cd ..
	rm -Rf pkgtmp
	umount mnt
	exit 1
fi

# If telnet access it enabled, disable it
[ -r etc/remote.allow ] && rm -f etc/remote.allow

cp -f ../shadow.tmp etc/shadow
chmod 600 etc/shadow

rm -f ../${ETCFILE}
tar -czf ../${ETCFILE} .

cd ..
cp -f $ETCFILE mnt/
rm -Rf pkgtmp
rm $ETCFILE
umount mnt
sync

echo "Password removal complete."
echo


