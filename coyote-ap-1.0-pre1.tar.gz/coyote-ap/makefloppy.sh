#!/bin/sh
#
#

# load standard functions
. scripts/functions
. scripts/cfg-local

CONFIG_FILE=floppy/coyote.cfg

clear
echo
echo "Coyote AP floppy builder script v1.0"
echo

if ! [ "$UID" = "0" ]; then
	echo "You should be logged in as root to create the Coyote AP floppy disk. Non-root users"
	echo "can experience permission problems under some distributions when attempting to"
	echo "access the floppy drive.  To cancel, press CTRL-C... to proceed, press enter"
	read JUNK
fi

reset_all

if [ "$1" = "-i" ]; then
	if [ ! -r flp.img ]; then
		echo "Floppy image update specified but no floppy image is present."
		exit 1
	fi
	DOFMT=NO
	DOIMG=YES
	FDCAPACITY=1440
    	FLOPPY=/dev/fd0u1440
else
	DOIMG=NO
    	FDCAPACITY=1440
    	if [ -a /dev/fd0u1440 ]; then
    		FLOPPY=/dev/fd0u1440
    	elif [ -a /dev/fd0H1440 ]; then
    		FLOPPY=/dev/fd0H1440
    	elif [ -a /dev/fd0h1440 ]; then
    		FLOPPY=/dev/fd0h1440
    	else
    		# No device available... try using a built-in
    		FLOPPY=data/dev/fd0u1440
    	fi			
	if [ "$1" = "-n" ]; then
    		DOFMT=NO
    	else
		DOFMT=YES
    	fi
fi

ln -s data/kernel-nofpu/drivers drivers
ln -s ../data/kernel-nofpu/floppy/linux floppy/linux

. scripts/mkflp-ap

