#!/bin/sh
#
#

echo -n "Cleaning Coyote AP distribution..."
. ./scripts/functions
reset_all
echo " done."
