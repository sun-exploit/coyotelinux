#!/bin/sh
#
#

for KFILE in nofpu; do
	echo "Copying new kernel ($KFILE)..."
	rm -f data/kernel-$KFILE/floppy/linux
	cp buildroot/devel/binout/kernel-$KFILE/linux data/kernel-$KFILE/floppy/linux
	rdev data/kernel-$KFILE/floppy/linux /dev/fd0
	echo "Updating modules ($KFILE)..."
	rm -f data/kernel-$KFILE/drivers/*
	find buildroot/devel/binout/modules-$KFILE -name *.o -print | while read MODNAME; do
		cp $MODNAME data/kernel-$KFILE/drivers/
	done
	cp buildroot/devel/binout/modules-$KFILE/System.map data/kernel-$KFILE

	# Update the dependencies file
	SAVEDIR=`pwd`
	cd data/kernel-$KFILE/drivers
	depmod -F ../System.map -n * > ../modules.dep
	cd $SAVEDIR
done

# [ -d source/kernel/netdrivers ] && cp -f source/kernel/netdrivers/*.o data/$KFILE/drivers/

echo "Kernel with FPU emulation:"
ls -l data/kernel-nofpu/floppy/linux
#echo "Kernel without FPU emulation:"
#ls -l data/kernel-fpu/floppy/linux

if [ -d winsrc/cdimage ] && [ "$1" = "-u" ]; then
	echo "Updating Windows CD Image drivers..."
	cp drivers/* winsrc/cdimage/Files/modules/
fi
