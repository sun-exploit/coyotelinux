#!/bin/sh
#
# Creates all of the packages from the source package directories

buildpkg ()
{
	echo "Building package: ${PKGNAME}"
	rm -f ../packages/${PKGNAME}.tgz 2>&1 > /dev/null
	cd $PKGNAME
	tar -cf ../../packages/${PKGNAME}.tar *
	cd ../../packages
	gzip -9 ${PKGNAME}.tar
	mv ${PKGNAME}.tar.gz ${PKGNAME}.tgz
	cd ../pkgsrc
}

cd pkgsrc

for PKGNAME in `ls`; do 
	buildpkg
done

cd ..

NEED4WIN="dhcpd oidentd ppp pppoe rrlogind"

if [ "$1" = "-u" ] && [ -a winsrc/cdimage/linux/packages ]; then
	echo "Updating Windows source packages"
	cp packages/* winsrc/cdimage/linux/packages/
	for PKG in $NEED4WIN; do
		cp packages/${PKG}.lrp winsrc/cdimage/Files/packages/
	done 
fi

if [ -r flp.img ] && [ "$1" = "-f" ]; then
	echo "Updating VM floppy image..."
	mount flp.img mnt -o loop
	cd mnt
	[ -r config.tgz ] && cp -f config.tgz ../floppy/
	cp -f ../floppy/* .
	cd ..
	umount mnt
fi
